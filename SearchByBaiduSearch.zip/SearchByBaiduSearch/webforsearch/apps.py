from django.apps import AppConfig


class WebforsearchConfig(AppConfig):
    name = 'webforsearch'
