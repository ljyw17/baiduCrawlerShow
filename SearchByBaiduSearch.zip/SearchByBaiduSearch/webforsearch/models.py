from django.db import models
# Create your models here.



class Content(models.Model):
    content_id = models.CharField(max_length=50, default="", primary_key=True)
    keyword = models.CharField(max_length=20, null=False)
    title = models.CharField(max_length=50, null=False)
    link = models.CharField(max_length=1000, null=False)
    date_time = models.CharField(max_length=20, null=True)
    description = models.CharField(max_length=1000, null=True)